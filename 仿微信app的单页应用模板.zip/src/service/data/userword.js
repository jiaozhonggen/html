//对话的数据


import {imgurl} from 'src/config/env';

export const userWord=[
	{
		"wxid":"812571880",
		"headurl":imgurl+'chen.jpg',
		"sendobject":0,
		"Messageblob":"人生没有彩排，每天都是直播，不仅收视率低，而且工资不高。",
	},
]