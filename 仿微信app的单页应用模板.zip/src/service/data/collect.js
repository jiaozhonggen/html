//我的收藏
/*通讯录所以联系人
*	wxid:微信号
*	headurl:头像图片地址
*	petname:昵称
*	sex:性别(男0女1)
*	remarks:备注
* 	collectext:收藏的文本
*	collectimg:收藏的图片
*	collectime:收藏的时间
*
*
*	imgurl:图片地址
*/	

import {imgurl} from 'src/config/env';
export const collect=[
	{
		"wxid":"achuqiao",
		"headurl":imgurl+'chuqiao.jpg',
		"petname":"a楚乔",
		"sex":1,
		"remarks":"楚乔",
		"collectext":"儿童节快到了，这边为大家推荐一款宝宝性格养成书哈。月销近万哦，会发声的绘本故事呢",
		"collectimg":"",
		"collectime":"今天",
	},
	{
		"wxid":"caiawei",
		"headurl":imgurl+'caiwei.jpg',
		"petname":"采薇",
		"sex":1,
		"remarks":"",
		"collectext":"",
		"collectimg":imgurl+'d.jpg',
		"collectime":"昨天",
	},
	{
		"wxid":"liangshaoqing",
		"headurl":imgurl+'liangshaoqing.jpg',
		"petname":"梁少卿",
		"sex":0,
		"remarks":"",
		"collectext":"",
		"collectimg":imgurl+'d.jpg',
		"collectime":"昨天",
	},
	{
		"wxid":"chenchangsheng",
		"headurl":imgurl+'chenchangsheng.jpg',
		"petname":"陈长生",
		"sex":0,
		"remarks":"",
		"collectext":"思落",
		"collectimg":"",
		"collectime":"昨天",
	},
	{
		"wxid":"ayuwenyue",
		"headurl":imgurl+'yuwenyue.jpg',
		"petname":"a宇文玥",
		"sex":0,
		"remarks":"",
		"collectext":"",
		"collectimg":imgurl+'chenyuan.jpg',
		"collectime":"昨天",
	},
]

