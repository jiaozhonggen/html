//对话列表

/*
*
*headurl:对话人头像
*remarks:对话人名字
*newmeassage:对话最新一条消息
*sendobject:发送信息的对象(1是别人0是自己)
*Messageblob:消息内容
*
*
*
*
*
*
*
*
*/

import {imgurl} from 'src/config/env';

export const dialog = [
{
	"wxid":"fileTransfer",
	"headurl":imgurl+'robot.jpg',
	"petname":"机器人聊天",
	"remarks":"机器人聊天",
	"newmeassage":"请从通讯录的联系人进入机器人单人聊天",
	"sendobject":1,
},
]
