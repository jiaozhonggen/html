export const search = [
{
	title: "朋友圈"
},
{
	title: "文章"
},
{
	title: "公众号"
},
{
	title: "小说"
},
{
	title: "音乐"
},
{
	title: "表情"
}
]