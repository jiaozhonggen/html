<template>
	<section>
		<head-top logo-part="true" search-part="true" add="true"></head-top>
		传送文件
		<foot-guide></foot-guide>
	</section>	
</template>

<script>
	import headTop from '../../components/header/head'
	import footGuide from '../../components/footer/foot'
	export default{
		data(){
			return{
				
			}
		},
		created(){

		},
		mounted(){
			
		},
		components:{
			headTop,
			footGuide
		},
		computed:{
			
		},
		methods:{

		}
	}
</script>
<style lang="scss" scoped>
	@import "../../style/public";
	
</style>