$(function () {
	$('#diagram-id-1').circleDiagram();
	$('#diagram-id-2').circleDiagram();
	$('#diagram-id-3').circleDiagram();
	$('#datetimepicker1').datetimepicker();
});